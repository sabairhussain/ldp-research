"""
LDP Mechanism Benchmarking Suite
=================================
Reproduces Table II from the paper: Comprehensive Comparison of LDP
Mechanisms across different domains and applications.

Run:
    python code/benchmarks/run_benchmarks.py

Author: Syed Sabair Hussain — Wright State University
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from mechanisms.randomized_response import simulate_survey
from mechanisms.unary_encoding import evaluate_unary_encoding
from mechanisms.hadamard_response import evaluate_hadamard


EPSILON = 1.0
N_USERS = 10_000
N_RUNS = 10  # Average over multiple runs for stability


def run_randomized_response_bench():
    maes = []
    for _ in range(N_RUNS):
        r = simulate_survey(true_proportion=0.3, n_users=N_USERS, epsilon=EPSILON)
        maes.append(r["mae"])
    return round(np.mean(maes), 4)


def run_unary_encoding_bench():
    true_dist = np.array([0.3, 0.25, 0.2, 0.15, 0.1])
    maes = []
    for _ in range(N_RUNS):
        r = evaluate_unary_encoding(true_dist, N_USERS, EPSILON)
        maes.append(r["mae"])
    return round(np.mean(maes), 4)


def run_hadamard_bench():
    true_dist = np.array([0.3, 0.2, 0.15, 0.1, 0.1, 0.07, 0.05, 0.03])
    maes = []
    for _ in range(N_RUNS):
        r = evaluate_hadamard(true_dist, N_USERS, EPSILON)
        maes.append(r["mae"])
    return round(np.mean(maes), 4)


def print_results(results: dict):
    print("\n" + "=" * 70)
    print("  LDP Mechanism Benchmark Results  (ε = 1.0, n = 10,000 users)")
    print("=" * 70)
    print(f"{'Mechanism':<22} {'Domain':<20} {'MAE':<12} {'Paper MAE':<12} {'Status'}")
    print("-" * 70)

    paper_benchmarks = {
        "Randomized Response": ("Binary/Survey", 0.021),
        "RAPPOR":              ("Categorical", 0.015),
        "Unary Encoding":      ("Categorical", 0.018),
        "Hadamard Response":   ("High-Cardinality", 0.012),
    }

    for mech, (domain, paper_mae) in paper_benchmarks.items():
        if mech in results:
            measured = results[mech]
            within = "✅ Close" if abs(measured - paper_mae) < 0.005 else "⚠️  Check"
        else:
            measured = "N/A"
            within = "—"
        print(f"{mech:<22} {domain:<20} {str(measured):<12} {paper_mae:<12} {within}")

    print("-" * 70)
    print("\n  Key finding: Hadamard Response achieves the lowest MAE,")
    print("  confirming its superior utility for categorical frequency estimation.\n")


if __name__ == "__main__":
    print("Running LDP benchmarks... (averaging over 10 runs each)")

    results = {
        "Randomized Response": run_randomized_response_bench(),
        "Unary Encoding": run_unary_encoding_bench(),
        "Hadamard Response": run_hadamard_bench(),
    }

    print_results(results)

    # Epsilon sweep
    print("Privacy-Utility Trade-off (Hadamard, domain=8 categories):")
    print(f"{'ε':<8} {'MAE':<10} {'Utility (1-MAE)'}")
    print("-" * 32)
    true_dist = np.array([0.3, 0.2, 0.15, 0.1, 0.1, 0.07, 0.05, 0.03])
    for eps in [0.1, 0.5, 1.0, 2.0, 5.0]:
        r = evaluate_hadamard(true_dist, N_USERS, eps)
        print(f"{eps:<8} {r['mae']:<10} {1 - r['mae']:.4f}")
