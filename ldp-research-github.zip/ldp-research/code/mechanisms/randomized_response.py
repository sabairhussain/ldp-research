"""
Randomized Response - Local Differential Privacy Mechanism
==========================================================
The foundational LDP mechanism for binary data, originally proposed by 
Warner (1965) for sensitive surveys and adapted for digital privacy.

Author: Syed Sabair Hussain
Course: Masters in Cybersecurity — Wright State University
"""

import numpy as np


def randomized_response(value: int, epsilon: float) -> int:
    """
    Apply Randomized Response to a binary value.

    The user reports their true answer with probability p = e^ε / (1 + e^ε),
    and the opposite with probability 1 - p. This provides ε-LDP.

    Args:
        value   : True binary value (0 or 1)
        epsilon : Privacy budget (ε). Lower = more privacy, more noise.

    Returns:
        Perturbed binary value (0 or 1)
    """
    p = np.exp(epsilon) / (1 + np.exp(epsilon))
    return value if np.random.random() < p else 1 - value


def aggregate_randomized_response(reports: list, epsilon: float) -> float:
    """
    Debias a collection of Randomized Response reports to estimate
    the true proportion of 1s in the population.

    Args:
        reports : List of perturbed binary values from n users
        epsilon : Privacy budget used during collection

    Returns:
        Estimated true proportion of 1s
    """
    p = np.exp(epsilon) / (1 + np.exp(epsilon))
    n = len(reports)
    noisy_mean = sum(reports) / n
    # Inverse the noise: recover true proportion
    true_estimate = (noisy_mean - (1 - p)) / (2 * p - 1)
    return np.clip(true_estimate, 0, 1)


def simulate_survey(true_proportion: float, n_users: int, epsilon: float) -> dict:
    """
    Simulate a private survey using Randomized Response.

    Args:
        true_proportion : Actual fraction of users with sensitive attribute
        n_users         : Number of survey participants
        epsilon         : Privacy budget

    Returns:
        Dict with true value, estimate, and mean absolute error
    """
    true_values = np.random.binomial(1, true_proportion, n_users)
    perturbed = [randomized_response(v, epsilon) for v in true_values]
    estimate = aggregate_randomized_response(perturbed, epsilon)
    mae = abs(true_proportion - estimate)
    return {
        "true_proportion": true_proportion,
        "estimated_proportion": round(estimate, 4),
        "mae": round(mae, 4),
        "n_users": n_users,
        "epsilon": epsilon,
    }


if __name__ == "__main__":
    print("=" * 55)
    print("  Randomized Response — LDP Demo")
    print("=" * 55)

    # Sweep over epsilon values to show privacy-utility trade-off
    epsilons = [0.1, 0.5, 1.0, 2.0, 5.0]
    true_p = 0.3  # 30% of population has the sensitive attribute

    print(f"\nTrue proportion: {true_p}  |  Users: 10,000\n")
    print(f"{'ε':<8} {'Estimate':<12} {'MAE':<10} {'Privacy'}")
    print("-" * 45)
    for eps in epsilons:
        result = simulate_survey(true_p, 10000, eps)
        privacy = "High" if eps <= 0.5 else ("Medium" if eps <= 1.5 else "Low")
        print(f"{eps:<8} {result['estimated_proportion']:<12} {result['mae']:<10} {privacy}")
