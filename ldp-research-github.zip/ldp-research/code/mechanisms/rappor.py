"""
RAPPOR — Randomized Aggregatable Privacy-Preserving Ordinal Response
=====================================================================
Google's LDP mechanism deployed in Chrome for large-scale telemetry.
Uses Bloom filters + two-stage randomized response for categorical data.

Reference: Erlingsson et al. (2014) — ACM CCS, pp. 1054–1067.
Author: Syed Sabair Hussain — Wright State University
"""

import numpy as np
import hashlib
from typing import List


# --- Bloom Filter Helpers ---

def _bloom_filter(value: str, num_bits: int, num_hashes: int) -> np.ndarray:
    """Create a Bloom filter bit array for a string value."""
    bits = np.zeros(num_bits, dtype=int)
    for i in range(num_hashes):
        h = int(hashlib.md5(f"{value}{i}".encode()).hexdigest(), 16)
        bits[h % num_bits] = 1
    return bits


# --- RAPPOR Stages ---

def rappor_permanent_rr(bloom_bits: np.ndarray, f: float) -> np.ndarray:
    """
    Stage 1 (Permanent Randomized Response): Create a stable but noisy
    encoding S of the Bloom filter B. Each bit is flipped with prob f/2.
    This encoding is reused across reports from the same user.

    Args:
        bloom_bits : True Bloom filter bits
        f          : Permanent noise parameter (typically 0.5)

    Returns:
        Permanent randomized response bit array
    """
    S = np.copy(bloom_bits)
    for i in range(len(S)):
        r = np.random.random()
        if r < f / 2:
            S[i] = 1
        elif r < f:
            S[i] = 0
    return S


def rappor_instantaneous_rr(S: np.ndarray, q: float, p: float) -> np.ndarray:
    """
    Stage 2 (Instantaneous Randomized Response): Each report adds fresh
    noise on top of S to prevent tracking across multiple reports.

    Args:
        S : Permanent randomized response from Stage 1
        q : Probability of reporting 1 when S[i] = 1
        p : Probability of reporting 1 when S[i] = 0

    Returns:
        Final perturbed bit array to transmit
    """
    report = np.zeros(len(S), dtype=int)
    for i, bit in enumerate(S):
        prob = q if bit == 1 else p
        report[i] = 1 if np.random.random() < prob else 0
    return report


def rappor_encode(value: str, epsilon: float,
                  num_bits: int = 16, num_hashes: int = 2,
                  f: float = 0.5) -> np.ndarray:
    """
    Full RAPPOR encoding pipeline for a single user.

    Args:
        value     : User's categorical string value
        epsilon   : Privacy budget ε
        num_bits  : Size of Bloom filter
        num_hashes: Number of hash functions
        f         : Permanent noise parameter

    Returns:
        Final perturbed bit array
    """
    # Calibrate q, p from epsilon
    p = 0.5
    q = np.exp(epsilon / 2) / (1 + np.exp(epsilon / 2))

    bloom = _bloom_filter(value, num_bits, num_hashes)
    S = rappor_permanent_rr(bloom, f)
    report = rappor_instantaneous_rr(S, q, p)
    return report


def rappor_aggregate(reports: List[np.ndarray], candidates: List[str],
                     num_bits: int = 16, num_hashes: int = 2,
                     f: float = 0.5, epsilon: float = 1.0) -> dict:
    """
    Aggregate RAPPOR reports and estimate frequency of each candidate.

    Args:
        reports    : List of perturbed bit arrays from all users
        candidates : List of possible categorical values
        num_bits   : Bloom filter size
        num_hashes : Number of hash functions
        f, epsilon : Parameters matching encoding

    Returns:
        Dict mapping candidate -> estimated frequency
    """
    n = len(reports)
    p_param = 0.5
    q_param = np.exp(epsilon / 2) / (1 + np.exp(epsilon / 2))

    # Aggregate reports
    sum_reports = np.sum(reports, axis=0)

    frequencies = {}
    for candidate in candidates:
        bloom = _bloom_filter(candidate, num_bits, num_hashes)
        # For each set bit in the bloom filter, estimate from aggregate
        est = 0
        count = 0
        for i, b in enumerate(bloom):
            if b == 1:
                # Expected fraction of 1s in position i if this candidate is true
                exp_q = q_param * (1 - f / 2) + p_param * (f / 2)
                exp_p = q_param * (f / 2) + p_param * (1 - f / 2)
                frac = sum_reports[i] / n
                est += (frac - exp_p) / (exp_q - exp_p)
                count += 1
        frequencies[candidate] = max(0, est / count) if count > 0 else 0

    # Normalize
    total = sum(frequencies.values())
    if total > 0:
        frequencies = {k: v / total for k, v in frequencies.items()}
    return frequencies


if __name__ == "__main__":
    print("=" * 55)
    print("  RAPPOR — LDP Demo (Google Chrome Mechanism)")
    print("=" * 55)

    candidates = ["cat_A", "cat_B", "cat_C", "cat_D"]
    true_dist = {"cat_A": 0.4, "cat_B": 0.3, "cat_C": 0.2, "cat_D": 0.1}
    n_users = 5000

    print(f"\nCategories: {candidates}")
    print(f"Users: {n_users}  |  ε = 1.0\n")

    # Simulate users sending reports
    user_values = np.random.choice(
        candidates, size=n_users, p=list(true_dist.values())
    )
    reports = [rappor_encode(v, epsilon=1.0) for v in user_values]
    estimated = rappor_aggregate(reports, candidates, epsilon=1.0)

    print(f"{'Category':<12} {'True Freq':<14} {'Estimated'}")
    print("-" * 38)
    for cat in candidates:
        print(f"{cat:<12} {true_dist[cat]:<14.2f} {estimated.get(cat, 0):.4f}")

    mae = np.mean([abs(true_dist[c] - estimated.get(c, 0)) for c in candidates])
    print(f"\nMAE: {mae:.4f}  (paper benchmark: ~0.015 at ε=1.0)")
