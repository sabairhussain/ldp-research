"""
Unary Encoding (UE) — Local Differential Privacy Mechanism
===========================================================
Represents categorical data as binary one-hot vectors then
independently perturbs each bit. Simpler than RAPPOR, with
MAE typically between 0.013–0.018 at ε=1.0.

Author: Syed Sabair Hussain — Wright State University
"""

import numpy as np
from typing import List


def unary_encode(value: int, domain_size: int, epsilon: float) -> np.ndarray:
    """
    Symmetrical Unary Encoding (SUE) for one categorical value.

    Args:
        value       : True category index [0, domain_size)
        domain_size : Total number of categories
        epsilon     : Privacy budget ε

    Returns:
        Perturbed binary vector of length domain_size
    """
    p = np.exp(epsilon / 2) / (1 + np.exp(epsilon / 2))
    q = 1 / (1 + np.exp(epsilon / 2))

    # One-hot encode
    one_hot = np.zeros(domain_size, dtype=int)
    one_hot[value] = 1

    # Perturb each bit
    report = np.zeros(domain_size, dtype=int)
    for i in range(domain_size):
        prob = p if one_hot[i] == 1 else q
        report[i] = 1 if np.random.random() < prob else 0

    return report


def unary_aggregate(reports: List[np.ndarray], domain_size: int, epsilon: float) -> np.ndarray:
    """
    Aggregate perturbed unary reports and estimate true frequencies.

    Args:
        reports     : List of perturbed bit arrays
        domain_size : Number of categories
        epsilon     : Privacy budget used during encoding

    Returns:
        Estimated frequency distribution (sums to 1)
    """
    p = np.exp(epsilon / 2) / (1 + np.exp(epsilon / 2))
    q = 1 / (1 + np.exp(epsilon / 2))
    n = len(reports)

    # Sum each position across all reports
    sums = np.sum(reports, axis=0)

    # Debias: recover true frequencies
    freq = (sums / n - q) / (p - q)
    freq = np.clip(freq, 0, None)
    if freq.sum() > 0:
        freq /= freq.sum()
    return freq


def evaluate_unary_encoding(true_dist: np.ndarray, n_users: int, epsilon: float) -> dict:
    domain_size = len(true_dist)
    true_values = np.random.choice(domain_size, size=n_users, p=true_dist)
    reports = [unary_encode(v, domain_size, epsilon) for v in true_values]
    estimated = unary_aggregate(reports, domain_size, epsilon)
    mae = np.mean(np.abs(true_dist - estimated))
    return {"mae": round(mae, 4), "epsilon": epsilon, "estimated": estimated.round(4).tolist()}


if __name__ == "__main__":
    print("=" * 55)
    print("  Unary Encoding — LDP Demo")
    print("=" * 55)

    true_dist = np.array([0.3, 0.25, 0.2, 0.15, 0.1])
    n_users = 10_000

    print(f"\nDomain: 5 categories  |  Users: {n_users}\n")
    print(f"{'ε':<8} {'MAE'}")
    print("-" * 20)
    for eps in [0.1, 0.5, 1.0, 2.0, 5.0]:
        result = evaluate_unary_encoding(true_dist, n_users, eps)
        print(f"{eps:<8} {result['mae']}")
