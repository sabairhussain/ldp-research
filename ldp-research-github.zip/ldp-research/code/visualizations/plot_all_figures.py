"""
Reproduce Paper Figures — LDP Research
=======================================
Generates all four figures used in the paper:
  - Fig 2: Privacy-Utility Trade-off (CDP vs LDP)
  - Fig 3: Throughput Comparison
  - Fig 4: LDP Mechanism Comparison (RAPPOR vs Hadamard)

Run:
    python code/visualizations/plot_all_figures.py

Author: Syed Sabair Hussain — Wright State University
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "../../figures/reproduced")
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ── Figure 2: Privacy-Utility Trade-off ────────────────────────────────────

def plot_privacy_utility_tradeoff():
    """Reproduce Fig. 2 from the paper."""
    epsilons = np.linspace(0.1, 2.0, 20)

    # Simulated utility (1 - MAE) — matches paper curves
    cdp_utility = 1.0 - 0.01 / (epsilons + 0.05)
    ldp_utility = 1.0 - 0.08 / (epsilons + 0.1)
    cdp_utility = np.clip(cdp_utility, 0.85, 1.02)
    ldp_utility = np.clip(ldp_utility, 0.78, 1.00)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(epsilons, cdp_utility, "b-o", markersize=4, label="Centralized DP")
    ax.plot(epsilons, ldp_utility, "orange", marker="s", markersize=4,
            linestyle="-", label="Local DP")

    ax.axvline(x=0.5, color="gray", linestyle=":", alpha=0.6)
    ax.axvline(x=1.0, color="gray", linestyle=":", alpha=0.6)

    ax.set_xlabel("Privacy Budget (ε)")
    ax.set_ylabel("Utility (1 - MAE)")
    ax.set_title("Privacy-Utility Trade-off")
    ax.legend()
    ax.set_xlim(0.1, 2.0)
    ax.set_ylim(0.75, 1.05)

    out = os.path.join(OUTPUT_DIR, "fig2_privacy_utility_tradeoff.png")
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {out}")


# ── Figure 3: Throughput Comparison ────────────────────────────────────────

def plot_throughput_comparison():
    """Reproduce Fig. 3 from the paper."""
    mechanisms = ["RAPPOR", "Hadamard", "OLH", "Laplace", "Gaussian"]
    throughputs = [1200, 950, 1800, 3500, 2800]
    colors = ["#555", "#666", "#888", "#bbb", "#aaa"]

    fig, ax = plt.subplots(figsize=(6.5, 4))
    bars = ax.bar(mechanisms, throughputs, color=colors, edgecolor="black", linewidth=0.5)

    for bar, val in zip(bars, throughputs):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 40,
                f"{val:,}", ha="center", va="bottom", fontsize=9, fontweight="bold")

    ax.set_xlabel("Privacy Mechanism")
    ax.set_ylabel("Records Processed/Second")
    ax.set_title("Throughput Comparison of Privacy Mechanisms")
    ax.set_ylim(0, 4000)

    out = os.path.join(OUTPUT_DIR, "fig3_throughput_comparison.png")
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {out}")


# ── Figure 4: LDP Mechanism Comparison (RAPPOR vs Hadamard) ────────────────

def plot_mechanism_comparison():
    """Reproduce Fig. 4 from the paper."""
    epsilons = [0.1, 0.5, 1.0, 2.0, 5.0]

    # Accuracy values from paper Table II / Fig. 4
    rappor_accuracy = [0.55, 0.68, 0.75, 0.82, 0.88]
    hadamard_accuracy = [0.62, 0.74, 0.83, 0.89, 0.92]

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(epsilons, rappor_accuracy, "b-o", label="RAPPOR", markersize=6)
    ax.plot(epsilons, hadamard_accuracy, "orange", marker="s", linestyle="-",
            label="Hadamard", markersize=6)

    ax.set_xlabel("Privacy Budget (ε)")
    ax.set_ylabel("Accuracy")
    ax.set_title("LDP Mechanism Comparison")
    ax.legend()
    ax.set_xlim(0, 5.5)
    ax.set_ylim(0.50, 0.97)
    ax.grid(True, alpha=0.3)

    out = os.path.join(OUTPUT_DIR, "fig4_ldp_mechanism_comparison.png")
    plt.tight_layout()
    plt.savefig(out, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {out}")


# ── Main ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Reproducing paper figures...\n")
    plot_privacy_utility_tradeoff()
    plot_throughput_comparison()
    plot_mechanism_comparison()
    print("\n✅ All figures saved to figures/reproduced/")
