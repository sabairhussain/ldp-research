# LDP Mechanism Guide

A concise reference for the five core LDP mechanisms implemented in this project.

---

## 1. Randomized Response
**Best for:** Binary/survey data  
**MAE at ε=1.0:** ~0.021

The oldest LDP mechanism (Warner, 1965). Users flip a coin — report truth with probability `p = eᵉ/(1+eᵉ)`, opposite with `1-p`. Simple, auditable, and mathematically elegant.

```python
from mechanisms.randomized_response import randomized_response
result = randomized_response(value=1, epsilon=1.0)
```

---

## 2. RAPPOR
**Best for:** Categorical string data (URLs, domains, app names)  
**MAE at ε=1.0:** ~0.015  
**Deployed by:** Google Chrome (millions of users)

Two-stage pipeline: Bloom filter → permanent randomized response → instantaneous randomized response. Handles repeated collection from same user without cumulative privacy loss.

```python
from mechanisms.rappor import rappor_encode
report = rappor_encode(value="my_category", epsilon=1.0)
```

---

## 3. Unary Encoding (SUE)
**Best for:** Moderate-cardinality categorical data  
**MAE at ε=1.0:** ~0.013–0.018

One-hot encodes the category, then independently perturbs each bit. Simpler than RAPPOR, predictable performance scaling.

```python
from mechanisms.unary_encoding import unary_encode
report = unary_encode(value=2, domain_size=10, epsilon=1.0)
```

---

## 4. Hadamard Response ✅ Best Utility
**Best for:** High-cardinality categorical data  
**MAE at ε=1.0:** ~0.012 (lowest among all mechanisms)

Leverages Hadamard matrix orthogonality to minimize variance in estimates. Requires only matrix operations — efficient on mobile/IoT devices.

```python
from mechanisms.hadamard_response import hadamard_encode
report = hadamard_encode(value=3, domain_size=16, epsilon=1.0)
```

---

## 5. Laplace / Gaussian Mechanisms
**Best for:** Numerical queries (counts, means, sums)  
**Throughput:** Laplace: 3500 rec/s | Gaussian: 2800 rec/s (highest throughput)

Standard DP mechanisms for numerical data. Laplace gives exact ε-DP; Gaussian gives (ε,δ)-DP with smoother noise.

```python
from mechanisms.laplace_gaussian import laplace_mechanism, gaussian_mechanism
dp_count = laplace_mechanism(true_value=5000, sensitivity=1.0, epsilon=1.0)
```

---

## Choosing a Mechanism

| Situation | Recommended Mechanism |
|---|---|
| Binary yes/no survey | Randomized Response |
| Categorical, few categories (≤ 20) | Unary Encoding |
| Categorical, many categories (> 20) | Hadamard Response |
| String/URL data, repeated collection | RAPPOR |
| Numerical counts/sums, fast throughput | Laplace |
| Federated learning gradients | Gaussian + clipping |

---

## Privacy Budget (ε) Guidelines

| ε Value | Privacy Level | Recommended For |
|---|---|---|
| 0.1 – 0.5 | Very Strong | Sensitive medical/financial data |
| 0.5 – 1.0 | Strong | General consumer analytics |
| 1.0 – 2.0 | Moderate | Internal telemetry |
| 2.0 – 5.0 | Mild | Research datasets |

The "knee" of the privacy-utility curve is typically around **ε ≈ 1.0**, which is the most common practical choice.
